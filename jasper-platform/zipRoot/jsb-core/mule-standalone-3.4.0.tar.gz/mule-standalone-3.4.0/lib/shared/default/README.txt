Shared domain classloader sample "default" domain.
