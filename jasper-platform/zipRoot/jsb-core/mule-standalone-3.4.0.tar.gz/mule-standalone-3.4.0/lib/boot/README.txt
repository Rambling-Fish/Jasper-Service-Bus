This directory contains the libraries used by the Java Service Wrapper 
(http://wrapper.tanukisoftware.org).
