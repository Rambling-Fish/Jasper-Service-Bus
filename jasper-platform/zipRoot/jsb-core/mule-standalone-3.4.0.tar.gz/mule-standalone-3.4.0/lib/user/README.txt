All libraries (.jar files) in this folder will be added to the classpath before 
starting Mule.  Therefore this is a convenient place for the user to add any 
additional libraries needed for his/her Mule project.
